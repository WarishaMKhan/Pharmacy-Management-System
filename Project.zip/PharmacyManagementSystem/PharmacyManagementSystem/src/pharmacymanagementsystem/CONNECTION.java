/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pharmacymanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class CONNECTION {

    public static Connection con = null;

    public static Connection GETCONNECTION() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=ResturantmanagementSystem;encrypt=true;trustServerCertificate=true", "rms", "12345");
            System.out.println("Connected");
            JOptionPane.showMessageDialog(null, "Succesfull database Connection");
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("ERROR MESSAGE: " + ex.getMessage());
        }
        return con;
    }
public static boolean authenticateUser(String enteredUsername, String enteredPassword) {
        try {
            // Load the JDBC driver and establish a connection
           Connection connection = GETCONNECTION();

            // SQL query to check username and password
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, enteredUsername);
                preparedStatement.setString(2, enteredPassword);

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();

                // Check if any rows are returned
                return resultSet.next();
            }
        } 
        catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

//    public static void closeConnection() {
//        try {
//            if (con != null && !con.isClosed()) {
//                con.close();
//                System.out.println("Connection closed");
//            }
//        } catch (SQLException ex) {
//            System.out.println("Error while closing connection: " + ex.getMessage());
//        }
//    }

    public static void main(String[] args) {
//       Connection connection = GETCONNECTION();
        TitlePage tp=new TitlePage();
        tp.setVisible(true);
        // Perform operations with the connection...

//        closeConnection(); // Close the connection when done.
    }
}
